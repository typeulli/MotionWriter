def main(img, data, func):
    return func.(data.file)